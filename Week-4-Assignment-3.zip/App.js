// import {
//   SafeAreaView,
//   StyleSheet,
//   View,
//   Text,
//   StatusBar,
//   Platform,
//   Dimensions,
//   ScrollView,
//   useWindowDimensions,
// } from "react-native";

// import {useDeviceOrientation} from '@react-native-community/hooks'
// import { useEffect, useState } from "react";

// export default function App() {
  
//   const orientation = useDeviceOrientation()
//   console.log('orientation is:', orientation)
//   const styles = 
//     StyleSheet.create({
//       box : {width:300, height:300, backgroundColor:"grey", marginTop:50}
//     })
  
//   const [style, setStyle] = useState(styles);
//   useEffect(()=>{
//     if(orientation === "landscape"){
//       setStyle({
//         ...style,
//         box: { ...style.box, width: 600, height:100, backgroundColor:"grey" }
//       });  
//     }
//     else{
//       setStyle({
//         ...style,
//         box: { ...style.box, width:300, height:300, backgroundColor:"orange" }
//       });
//     }
//   },[orientation])
  
//   // if(orientation === "landscape"){
//   //   return(
//   //     <SafeAreaView>
//   //     <View style={{width:600, height:200, backgroundColor:"crimson", marginTop:50}}>
//   //     </View>
//   //   </SafeAreaView>
//   //   )
//   // }

//   // return (
//   //   <SafeAreaView>
//   //     <View style={{width:300, height:300, backgroundColor:"grey", marginTop:50}}>
//   //     </View>
//   //   </SafeAreaView>
//   // );

//   return (
//     <SafeAreaView>
//       <View style={{...style.box}}>
//       </View>
//     </SafeAreaView>
//   );

// }

import {useDeviceOrientation} from '@react-native-community/hooks'
import { Text } from 'react-native';
import { SafeAreaView, StyleSheet, View, useWindowDimensions } from 'react-native';
 
 
const styles = StyleSheet.create({
  box : { width : 200, height : 400, backgroundColor : "silver" }
})
 
export default function App() {
  let orientation = useDeviceOrientation();
  let dimension = useWindowDimensions()
  return <View style={ {display : 'flex', alignItems : "center", justifyContent : "center", height : dimension.height } }>
            <View style={[styles.box, {backgroundColor : orientation === "landscape" ? "green" : "red",  }]}>
              <Text style={ {textAlign : 'center', fontSize : 20,fontWeight : "bold", color : "white" } }>{orientation}</Text>
            </View>
         </View>;
}