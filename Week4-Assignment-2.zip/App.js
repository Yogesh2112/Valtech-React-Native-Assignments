import { useState } from "react";
import { Pressable, SafeAreaView, ScrollView, StyleSheet, View } from "react-native";


export default function App() {

  // let [width1, setWidth1] = useState("50%")

  // let styles = StyleSheet.create({
  //   box : {width:width1, height:150, backgroundColor:"grey", marginBottom:10},
  //   firstbox : { marginTop: 50}
  // })
  
  let styles = StyleSheet.create({
    box : {width:"50%", height:150, backgroundColor:"grey", marginBottom:10},
    firstbox : { marginTop: 50}
  })
  
  let [style, setStyle] = useState(styles)

  let clickHandler = () => {
    setStyle({
      ...style,
      box: { ...style.box, width: "100%" }
    });

    // setWidth1("100%");
  }

  return <SafeAreaView>
    <Pressable onPress={clickHandler}>
    <View  style={[style.box, styles.firstbox]}></View>
      
    <View style={{...style.box, backgroundColor:"cyan"}}></View>
    <View style={{...style.box, backgroundColor:"yellow"}}></View>
    <View style={{...style.box, backgroundColor:"black"}}></View>
    <View style={ [ style.box, {backgroundColor:"#f455ad"}] }></View>
    
    </Pressable>
    {/* <View style={{width:200, height:200, backgroundColor : "cyan"}}></View>
    <View style={{width:200, height:200, backgroundColor : "#c922c1"}}></View>
    <View style={{width:200, height:200, backgroundColor : "yellow"}}></View>
    <View style={{width:200, height:200, backgroundColor : "black"}}></View> */}

  </SafeAreaView>;
}
