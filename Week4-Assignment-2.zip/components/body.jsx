import { Image, ImageBackground, SafeAreaView, ScrollView, Text, View } from "react-native";

const city = [
    {name: "Bangalore", poster:require("../assets/images/batman.jpg")},
    {name: "Jaipur", poster: require("../assets/images/ironman.jpg")},
    {name: "Delhi", poster: require("../assets/images/spiderman.jpg")},
    {name: "Kolkata", poster: require("../assets/images/superman.jpg")},
    {name: "Dubai", poster: require("../assets/images/thor.jpg")},
    {name: "Chennai", poster: require("../assets/images/hulk.jpg")},
    {name: "Mumbai", poster: require("../assets/images/hulk.jpg")},
    {name: "Pune", poster: require("../assets/images/hulk.jpg")},
    {name: "Mangalore", poster: require("../assets/images/hulk.jpg")},
    {name: "Jhasi", poster: require("../assets/images/wonderwoman.jpg")},
]


let Body = () =>{
    return <SafeAreaView style={{height:"auto"}}>
        <ScrollView>
          <View style={{ display: "flex",flexDirection:"row", flexWrap: "wrap" }}>
        {city.map((val,idx)=> <View key={idx} style={{ margin: 20 }}>
          <ImageBackground style={{width:150, height:150, position:"relative"}} source={val.poster}>
            <Text style={{width:150 ,color:"white", position:"absolute", top:130, backgroundColor:"black", textAlign:"center"}}>{val.name}</Text>
          </ImageBackground>
        </View>)}
    </View>
    </ScrollView>
    </SafeAreaView>
}

export default Body;